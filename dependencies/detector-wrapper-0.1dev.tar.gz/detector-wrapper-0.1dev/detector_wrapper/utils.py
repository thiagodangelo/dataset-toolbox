# coding: utf-8
import pathlib
import cv2

import numpy as np


class FileCapture(object):
    def __init__(self, path: str):
        self.path = pathlib.Path(path)
        self.generator = self.path.rglob('*.jpg')
    
    def read(self) -> (bool, np.ndarray):
        filename = next(self.generator, None)
        if filename is None:
            return False, None 
        image = cv2.imread(str(filename))
        return True, image
        