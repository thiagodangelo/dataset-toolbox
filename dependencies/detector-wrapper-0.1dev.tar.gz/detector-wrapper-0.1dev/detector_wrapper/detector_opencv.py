# coding: utf-8
import cv2

import numpy as np

from detector_wrapper.detector_interface import DetectorInterface
from detector_wrapper.errors import ExtraModelFilesError, MissingModelFilesError


class CvTensorflowDetector(DetectorInterface):
    def __init__(self, model_files: list):
        super().__init__(model_files)
        if len(self.model_files) > 2:
            raise ExtraModelFilesError("CvTensorflowDetector needs two model files")
        elif len(self.model_files) < 2:
            raise MissingModelFilesError("CvTensorflowDetector needs two model files")
        try:
            pb_file = list(filter(lambda x: x.endswith(".pb"), self.model_files))[0]
        except IndexError:
            raise MissingModelFilesError("Missing .pb file")
        try:
            pbtxt_file = list(filter(lambda x: x.endswith(".pbtxt"), self.model_files))[
                0
            ]
        except IndexError:
            raise MissingModelFilesError("Missing .pbtxt file")
        self.model = cv2.dnn.readNetFromTensorflow(pb_file, pbtxt_file)

    def detect(
        self,
        image: np.ndarray,
        rects: list,
        confs: list = None,
        conf_threshold: float = 0.30,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        image_height, image_width = image.shape[:2]
        self.model.setInput(cv2.dnn.blobFromImage(image, size=(300, 300), swapRB=True))
        output = self.model.forward()
        for detection in output[0, 0, :, :]:
            class_id = int(detection[1])
            confidence = float(detection[2])
            x1 = int(detection[3] * image_width)
            y1 = int(detection[4] * image_height)
            x2 = int(detection[5] * image_width)
            y2 = int(detection[6] * image_height)
            x, y, w, h = x1, y1, x2 - x1, y2 - y1
            rect = [x, y, w, h]
            if confidence < conf_threshold:
                continue
            if class_whitelist is not None and class_id not in class_whitelist:
                continue
            rects.append(rect)
            if confs is not None:
                confs.append(confidence)
            if classes is not None:
                class_name = None
                if class_names is not None:
                    class_name = class_names.get(class_id)
                classes.append(class_name or str(class_id))

    def postprocess(
        self,
        image: np.ndarray,
        rects: list,
        confs: list,
        conf_threshold: float = 0.30,
        nms_threshold: float = 0.50,
        penalty_factor: float = 0.7,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        if len(rects) > 0:
            all_idxs = set(range(len(rects)))
            exclude_idxs = set()
            image_height, image_width = image.shape[:2]
            for i, (rect, conf) in enumerate(zip(rects, confs)):
                x, y, w, h = rect
                if x > image_width and y > image_height:
                    exclude_idxs.add(i)
                if x <= 0 or y<=0 or x+w >= image_width or y+h >= image_height:
                    confs[i] *= penalty_factor
            idxs = cv2.dnn.NMSBoxes(rects, confs, conf_threshold, nms_threshold)
            idxs = set(idx[0] for idx in idxs)
            exclude_idxs = exclude_idxs.union(all_idxs - idxs)
            del_cnt = 0
            for idx in exclude_idxs:
                del rects[idx - del_cnt]
                del confs[idx - del_cnt]
                if classes is not None:
                    del classes[idx - del_cnt]
                del_cnt += 1


class CvCaffeDetector(DetectorInterface):
    def __init__(self, model_files: list):
        super().__init__(model_files)
        if len(self.model_files) > 2:
            raise ExtraModelFilesError("CvCaffeDetector needs two model files")
        elif len(self.model_files) < 2:
            raise MissingModelFilesError("CvCaffeDetector needs two model files")
        try:
            caffe_file = list(
                filter(lambda x: x.endswith(".caffemodel"), self.model_files)
            )[0]
        except IndexError:
            raise MissingModelFilesError("Missing .caffemodel file")
        try:
            prototxt_file = list(
                filter(lambda x: x.endswith(".prototxt"), self.model_files)
            )[0]
        except IndexError:
            raise MissingModelFilesError("Missing .prototxt file")
        self.model = cv2.dnn.readNetFromCaffe(prototxt_file, caffe_file)

    def detect(
        self,
        image: np.ndarray,
        rects: list,
        confs: list = None,
        conf_threshold: float = 0.30,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        image_height, image_width = image.shape[:2]
        self.model.setInput(
            cv2.dnn.blobFromImage(
                image, size=(300, 300), mean=(104.0, 177.0, 123.0), swapRB=True
            )
        )
        output = self.model.forward()
        for detection in output[0, 0, :, :]:
            class_id = int(detection[1])
            confidence = float(detection[2])
            x1 = int(detection[3] * image_width)
            y1 = int(detection[4] * image_height)
            x2 = int(detection[5] * image_width)
            y2 = int(detection[6] * image_height)
            x, y, w, h = x1, y1, x2 - x1, y2 - y1
            rect = [x, y, w, h]
            if confidence < conf_threshold:
                continue
            if class_whitelist is not None and class_id not in class_whitelist:
                continue
            rects.append(rect)
            if confs is not None:
                confs.append(confidence)
            if classes is not None:
                class_name = None
                if class_names is not None:
                    class_name = class_names.get(class_id)
                classes.append(class_name or str(class_id))

    def postprocess(
        self,
        image: np.ndarray,
        rects: list,
        confs: list,
        conf_threshold: float = 0.30,
        nms_threshold: float = 0.50,
        penalty_factor: float = 0.7,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        if len(rects) > 0:
            all_idxs = set(range(len(rects)))
            exclude_idxs = set()
            image_height, image_width = image.shape[:2]
            for i, (rect, conf) in enumerate(zip(rects, confs)):
                x, y, w, h = rect
                if x > image_width and y > image_height:
                    exclude_idxs.add(i)
                if x <= 0 or y<=0 or x+w >= image_width or y+h >= image_height:
                    confs[i] *= penalty_factor
            idxs = cv2.dnn.NMSBoxes(rects, confs, conf_threshold, nms_threshold)
            idxs = set(idx[0] for idx in idxs)
            exclude_idxs = exclude_idxs.union(all_idxs - idxs)
            del_cnt = 0
            for idx in exclude_idxs:
                del rects[idx - del_cnt]
                del confs[idx - del_cnt]
                if classes is not None:
                    del classes[idx - del_cnt]
                del_cnt += 1

