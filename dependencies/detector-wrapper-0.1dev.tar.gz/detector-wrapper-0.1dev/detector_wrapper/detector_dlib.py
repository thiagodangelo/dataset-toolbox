# coding: utf-8
import cv2
import dlib

import numpy as np

from detector_wrapper.detector_interface import DetectorInterface
from detector_wrapper.errors import ExtraModelFilesError, MissingModelFilesError


class DlibFHogSvmDetector(DetectorInterface):
    def __init__(self, model_files: list):
        super().__init__(model_files)
        if len(self.model_files) > 1:
            raise ExtraModelFilesError("DlibFHogSvmDetector needs one model file")
        elif len(self.model_files) < 1:
            raise MissingModelFilesError("DlibFHogSvmDetector needs one model file")
        try:
            svm_file = list(filter(lambda x: x.endswith(".svm"), self.model_files))[0]
        except IndexError:
            raise MissingModelFilesError("Missing .svm file")
        self.model = dlib.fhog_object_detector(svm_file)
        
    def preprocess(
        self,
        image: np.ndarray,
        resize: bool = False,
        size: (int, int) = None,
        fx: float = None,
        fy: float = None,
    ) -> None:        
        image_height, image_width = image.shape[:2]
        self.resize = resize
        self.size = size
        self.fx = fx
        self.fy = fy
        if self.resize:
            if self.size is not None:
                w, h = self.size
                self.fx = w / image_width
                self.fy = h / image_height
            elif self.fx is not None and self.fy is not None:
                w = int(image_width * self.fx)
                h = int(image_height * self.fy)
                self.size = (w, h)
            else:
                Warning("You must provide size argument or both fx and fy arguments. The image will not be resized")
                w, h = image_width, image_height
                self.size = (w, h)
                self.fx = 1
                self.fy = 1

    def detect(
        self,
        image: np.ndarray,
        rects: list,
        confs: list = None,
        conf_threshold: float = 0.30,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        image_height, image_width = image.shape[:2]
        fx, fy = 1, 1
        if self.resize:
            image = cv2.resize(image, self.size)
            fx, fy = self.fx, self.fy
        dets, scores, _ = self.model.run(image=image, upsample_num_times=0, adjust_threshold=-1)
        max_score = max(scores) if scores else -1
        min_score = min(scores) if scores else -1
        d_score = max_score - min_score if len(scores) > 1 else 1
        for detection, score in zip(dets, scores):
            class_id = 0
            confidence = (score - min_score) / d_score
            x1 = int(detection.left() / fx)
            y1 = int(detection.top() / fy)
            x2 = int(detection.right() / fx)
            y2 = int(detection.bottom() / fy)
            x, y, w, h = x1, y1, x2 - x1, y2 - y1
            rect = [x, y, w, h]
            if confidence < conf_threshold:
                continue
            if class_whitelist is not None and class_id not in class_whitelist:
                continue
            rects.append(rect)
            if confs is not None:
                confs.append(confidence)
            if classes is not None:
                class_name = None
                if class_names is not None:
                    class_name = class_names.get(class_id)
                classes.append(class_name or str(class_id))

    def postprocess(
        self,
        image: np.ndarray,
        rects: list,
        confs: list,
        conf_threshold: float = 0.30,
        nms_threshold: float = 0.50,
        penalty_factor: float = 0.7,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        if len(rects) > 0:
            all_idxs = set(range(len(rects)))
            exclude_idxs = set()
            image_height, image_width = image.shape[:2]
            for i, (rect, conf) in enumerate(zip(rects, confs)):
                x, y, w, h = rect
                if x > image_width and y > image_height:
                    exclude_idxs.add(i)
                if x <= 0 or y<=0 or x+w >= image_width or y+h >= image_height:
                    confs[i] *= penalty_factor
            idxs = cv2.dnn.NMSBoxes(rects, confs, conf_threshold, nms_threshold)
            idxs = set(idx[0] for idx in idxs)
            exclude_idxs = exclude_idxs.union(all_idxs - idxs)
            del_cnt = 0
            for idx in exclude_idxs:
                del rects[idx - del_cnt]
                del confs[idx - del_cnt]
                if classes is not None:
                    del classes[idx - del_cnt]
                del_cnt += 1
