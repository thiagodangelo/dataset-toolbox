# coding: utf-8
from enum import Enum


class DetectorModel(Enum):
    DlibFHogSvm = 0
    CvTensorflow = 1
    CvCaffe = 2

    def __str__(self):
        return str(self.name)
