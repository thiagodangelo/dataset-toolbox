# coding: utf-8
from detector_wrapper.enums import DetectorModel
from detector_wrapper.detector_opencv import CvTensorflowDetector, CvCaffeDetector
from detector_wrapper.detector_dlib import DlibFHogSvmDetector

class DetectorFactory(object):
    @staticmethod
    def create(detector_model, model_files):
        detector = None
        if detector_model is DetectorModel.DlibFHogSvm:
            detector = DlibFHogSvmDetector(model_files)
        elif detector_model is DetectorModel.CvTensorflow:
            detector = CvTensorflowDetector(model_files)
        elif detector_model is DetectorModel.CvCaffe:
            detector = CvCaffeDetector(model_files)
        return detector