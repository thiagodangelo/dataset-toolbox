# coding: utf-8

class Error(Exception):
    pass


class MissingModelFilesError(Error):
    pass


class ExtraModelFilesError(Error):
    pass

