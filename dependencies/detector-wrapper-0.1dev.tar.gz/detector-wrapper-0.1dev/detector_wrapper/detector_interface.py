# coding: utf-8
import numpy as np


class DetectorInterface(object):
    def __init__(self, model_files: list):
        self.model_files = model_files
        self.model = None
        self.resize = False
        self.size = None
        self.fx = 1
        self.fy = 1
    

    def preprocess(
        self,
        image: np.ndarray,
        resize: bool = False,
        size: (int, int) = None,
        fx: float = None,
        fy: float = None,
    ) -> None:
        raise NotImplementedError

    def detect(
        self,
        image: np.ndarray,
        rects: list,
        confs: list = None,
        conf_threshold: float = 0.30,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        raise NotImplementedError

    def postprocess(
        self,
        image: np.ndarray,
        rects: list,
        confs: list = None,
        conf_threshold: float = 0.30,
        nms_threshold: float = 0.50,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        raise NotImplementedError

    def pipeline(
        self,
        image: np.ndarray,
        rects: list,
        confs: list = None,
        conf_threshold: float = 0.30,
        nms_threshold: float = 0.50,
        classes: list = None,
        class_whitelist: list = None,
        class_names: dict = None,
    ) -> None:
        self.preprocess(image)
        self.detect(
            image, rects, confs, conf_threshold, classes, class_whitelist, class_names
        )
        self.postprocess(
            image, rects, confs, conf_threshold, classes, class_whitelist, class_names
        )
