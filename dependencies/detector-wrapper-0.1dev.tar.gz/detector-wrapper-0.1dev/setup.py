# coding: utf-8
from distutils.core import setup


setup(
    name='detector-wrapper',
    version='0.1dev',
    packages=['detector_wrapper',],
    license='LICENSE',
    long_description='README',
)